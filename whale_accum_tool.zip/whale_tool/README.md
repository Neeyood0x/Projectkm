# GrokBot – Whale Accumulation & Volume Surge Scanner

**All-in-one free tool** (CLI + Telegram bot) for spotting early on-chain accumulation, volume surges, and potential smart-money / whale footprints on small-cap tokens (Solana, Ethereum, Base, BSC, etc.).

Designed for Binance Alpha / TGE tokens, low-float plays, Solana memes & infra, Ethereum small caps.

## Two ways to use it

### 1. CLI
```bash
pip install requests
python whale_accum_scanner.py search AXIS
python whale_accum_scanner.py analyze solana <pair_or_mint>
python whale_accum_scanner.py surge --min-vol 30000 --max-mc 25000000
python whale_accum_scanner.py report ethereum 0x...
```

### 2. Telegram Bot – **GrokBot** (recommended)
```bash
# 1. Create bot with @BotFather → copy token
export TELEGRAM_BOT_TOKEN="123456789:AAH..."

# 2. Install
pip install -r requirements.txt

# 3. Run (keep the process alive)
python grokbot.py
```

Open the bot in Telegram and use:

| Command | Description |
|---------|-------------|
| `/start` `/help` | Show help & examples |
| `/search <name or CA>` | Search pairs, rank by accum score + volume |
| `/analyze <chain> <address>` | Full deep-dive with buttons |
| `/surge [query]` | Live scan for volume surges + accumulation flags |
| `/report <chain> <address>` | Same as analyze (chat-friendly) |

GrokBot replies with:
- Price, MC, liquidity, age
- Multi-timeframe volume
- Buy/sell pressure ratios
- Accum Score (0-100) + FLAGS
- One-tap buttons → DexScreener, Explorer, Birdeye, GMGN, Nansen, Arkham

## Signals detected

| Signal | Detection method |
|--------|------------------|
| **Volume surge** | 1h vs 6h average, 5m spikes |
| **Buy pressure / accumulation proxy** | Buy/sell txn ratios (1h & 24h) |
| **Early activity** | Young pairs (<48h) with real volume |
| **High turnover** | Volume relative to market-cap & liquidity |
| **Small-cap focus** | Configurable max market-cap filter |

**Flags**: `STRONG_BUY_PRESSURE_1H`, `NET_BUYISH_24H`, `VOLUME_SURGE_1H`, `VOLUME_SPIKE_5M`, `EARLY_HIGH_ACTIVITY`, `HIGH_VOL_TO_MCAP`, `HIGH_VOL_TO_LIQ`

## Workflow for Alpha / TGE hunting

1. `/search <new Alpha token name or CA>`
2. Look at Score + Flags
3. `/analyze <chain> <address>` on the interesting ones
4. Use the buttons to jump to Birdeye / GMGN / Nansen / Arkham
5. Confirm real Smart Money labels, holder clusters, exchange outflows
6. Re-run `/surge` during active windows

## Files

- `whale_accum_scanner.py` – core logic + CLI
- `grokbot.py` – Telegram bot wrapper
- `requirements.txt` – dependencies
- `README.md` – this file

## Limitations

- Free DexScreener data only (no Nansen/Arkham labels built-in)
- Rate limits apply – the code sleeps between calls
- Always verify contract, LP lock, team wallets, unlocks yourself
- **Not financial advice**

## Deeper stack (recommended)

- Nansen – Smart Money labels
- Arkham – entity / fund tracing
- Birdeye / GMGN – Solana holders & top traders
- Lookonchain – curated whale alerts
- Bubblemaps – holder clusters
- Dune – custom queries

Extend the bot with your own API keys for those services if you want.

---
Built for on-chain research. DYOR. Stay safe.
