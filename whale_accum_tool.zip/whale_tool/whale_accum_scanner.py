#!/usr/bin/env python3
"""
Whale Accumulation & Volume Surge Scanner
All-in-one free tool for spotting early accumulation, volume surges, and
smart-money footprints on Solana, Ethereum, Base, BSC and other chains.

Uses public DexScreener API (no key required).
Focus: small-cap / Binance Alpha-style TGE tokens, low-float plays.

Features:
- Token / pair search across chains
- Volume surge detection (5m / 1h / 6h / 24h)
- Buy/sell pressure & txn ratios (accumulation proxy)
- Liquidity + market-cap filters for small-caps
- New pair / early age signals
- Quick links to explorers + recommended deep tools (Nansen, Arkham, Birdeye...)
- Simple watchlist + report generation

Usage:
  python whale_accum_scanner.py search "token name or CA"
  python whale_accum_scanner.py analyze <chain> <pair_or_token_address>
  python whale_accum_scanner.py surge [--chain solana] [--min-vol 50000] [--max-mc 50000000]
  python whale_accum_scanner.py report <chain> <address>
  python whale_accum_scanner.py help

Disclaimer: Not financial advice. Data is public & delayed. Always verify
contracts, team, unlocks, and cross-check with paid labeling tools.
"""

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from urllib.parse import quote

try:
    import requests
except ImportError:
    print("Missing dependency: pip install requests")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
DEXSCREENER_BASE = "https://api.dexscreener.com"
RATE_LIMIT_SLEEP = 0.6  # be polite; DexScreener free tier can 429 under load

# Default small-cap focus
DEFAULT_MAX_MCAP = 80_000_000          # $80M
DEFAULT_MIN_LIQ = 5_000               # $5k
DEFAULT_MIN_VOL_24H = 10_000          # $10k
SURGE_THRESHOLDS = {
    "h1_vs_h6": 2.5,   # 1h volume > 2.5x average of previous
    "m5_spike": 3.0,
    "buy_ratio": 0.62, # buys / (buys+sells) > 62%
}

# Notable tool links (for report)
TOOL_LINKS = {
    "nansen": "https://app.nansen.ai",
    "arkham": "https://platform.arkhamintelligence.com",
    "birdeye": "https://birdeye.so",
    "dexscreener": "https://dexscreener.com",
    "solscan": "https://solscan.io",
    "etherscan": "https://etherscan.io",
    "bscscan": "https://bscscan.com",
    "basescan": "https://basescan.org",
    "dune": "https://dune.com",
    "lookonchain": "https://www.lookonchain.com",
    "gmgn": "https://gmgn.ai",
    "bubblemaps": "https://bubblemaps.io",
}

CHAIN_EXPLORERS = {
    "solana": "https://solscan.io/token/",
    "ethereum": "https://etherscan.io/token/",
    "base": "https://basescan.org/token/",
    "bsc": "https://bscscan.com/token/",
    "arbitrum": "https://arbiscan.io/token/",
    "polygon": "https://polygonscan.com/token/",
}

# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------
def _get(url: str, params: Optional[Dict] = None) -> Any:
    time.sleep(RATE_LIMIT_SLEEP)
    try:
        r = requests.get(url, params=params, timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"[API error] {e}")
        return None


def search_pairs(query: str) -> List[Dict]:
    data = _get(f"{DEXSCREENER_BASE}/latest/dex/search", {"q": query})
    if not data or "pairs" not in data:
        return []
    return data["pairs"] or []


def get_pairs_by_token(token_address: str) -> List[Dict]:
    data = _get(f"{DEXSCREENER_BASE}/latest/dex/tokens/{token_address}")
    if not data or "pairs" not in data:
        return []
    return data["pairs"] or []


def get_pair(chain: str, pair_address: str) -> Optional[Dict]:
    data = _get(f"{DEXSCREENER_BASE}/latest/dex/pairs/{chain}/{pair_address}")
    if not data or "pairs" not in data or not data["pairs"]:
        return None
    return data["pairs"][0]


# ---------------------------------------------------------------------------
# Analysis logic
# ---------------------------------------------------------------------------
def safe_float(val, default=0.0) -> float:
    try:
        return float(val) if val is not None else default
    except (TypeError, ValueError):
        return default


def analyze_pair(pair: Dict) -> Dict[str, Any]:
    """Extract key metrics + flags for accumulation / surge."""
    base = pair.get("baseToken", {})
    quote = pair.get("quoteToken", {})
    volume = pair.get("volume", {}) or {}
    txns = pair.get("txns", {}) or {}
    price_change = pair.get("priceChange", {}) or {}
    liquidity = pair.get("liquidity", {}) or {}

    vol_m5 = safe_float(volume.get("m5"))
    vol_h1 = safe_float(volume.get("h1"))
    vol_h6 = safe_float(volume.get("h6"))
    vol_h24 = safe_float(volume.get("h24"))

    tx_m5 = txns.get("m5", {}) or {}
    tx_h1 = txns.get("h1", {}) or {}
    tx_h6 = txns.get("h6", {}) or {}
    tx_h24 = txns.get("h24", {}) or {}

    buys_h1 = safe_float(tx_h1.get("buys"))
    sells_h1 = safe_float(tx_h1.get("sells"))
    buys_h24 = safe_float(tx_h24.get("buys"))
    sells_h24 = safe_float(tx_h24.get("sells"))

    total_h1 = buys_h1 + sells_h1
    buy_ratio_h1 = (buys_h1 / total_h1) if total_h1 > 0 else 0.0
    total_h24 = buys_h24 + sells_h24
    buy_ratio_h24 = (buys_h24 / total_h24) if total_h24 > 0 else 0.0

    # Volume surge heuristics
    avg_h6_per_h = vol_h6 / 6 if vol_h6 > 0 else 0
    surge_h1 = vol_h1 > (avg_h6_per_h * SURGE_THRESHOLDS["h1_vs_h6"]) if avg_h6_per_h > 0 else False
    surge_m5 = vol_m5 > (vol_h1 / 12 * SURGE_THRESHOLDS["m5_spike"]) if vol_h1 > 0 else False

    mcap = safe_float(pair.get("marketCap") or pair.get("fdv"))
    liq_usd = safe_float(liquidity.get("usd"))
    price_usd = safe_float(pair.get("priceUsd"))
    created_at = pair.get("pairCreatedAt")
    age_hours = None
    if created_at:
        age_hours = (time.time() * 1000 - created_at) / 3_600_000

    # Accumulation-style flags (proxy – not true net flow)
    flags = []
    if buy_ratio_h1 >= SURGE_THRESHOLDS["buy_ratio"] and buys_h1 >= 10:
        flags.append("STRONG_BUY_PRESSURE_1H")
    if buy_ratio_h24 >= 0.58 and buys_h24 >= 30:
        flags.append("NET_BUYISH_24H")
    if surge_h1:
        flags.append("VOLUME_SURGE_1H")
    if surge_m5:
        flags.append("VOLUME_SPIKE_5M")
    if age_hours is not None and age_hours < 48 and vol_h24 > 50_000:
        flags.append("EARLY_HIGH_ACTIVITY")
    if mcap > 0 and mcap < 5_000_000 and vol_h24 > mcap * 0.3:
        flags.append("HIGH_VOL_TO_MCAP")
    if liq_usd > 0 and vol_h24 > liq_usd * 2:
        flags.append("HIGH_VOL_TO_LIQ")

    score = 0
    if "STRONG_BUY_PRESSURE_1H" in flags:
        score += 25
    if "VOLUME_SURGE_1H" in flags:
        score += 20
    if "NET_BUYISH_24H" in flags:
        score += 15
    if "EARLY_HIGH_ACTIVITY" in flags:
        score += 15
    if "HIGH_VOL_TO_MCAP" in flags:
        score += 15
    if "VOLUME_SPIKE_5M" in flags:
        score += 10

    return {
        "chain": pair.get("chainId"),
        "dex": pair.get("dexId"),
        "pair_address": pair.get("pairAddress"),
        "url": pair.get("url"),
        "base_symbol": base.get("symbol"),
        "base_name": base.get("name"),
        "base_address": base.get("address"),
        "quote_symbol": quote.get("symbol"),
        "price_usd": price_usd,
        "price_change_h1": safe_float(price_change.get("h1")),
        "price_change_h24": safe_float(price_change.get("h24")),
        "volume": {
            "m5": vol_m5,
            "h1": vol_h1,
            "h6": vol_h6,
            "h24": vol_h24,
        },
        "txns": {
            "h1_buys": buys_h1,
            "h1_sells": sells_h1,
            "h24_buys": buys_h24,
            "h24_sells": sells_h24,
            "buy_ratio_h1": round(buy_ratio_h1, 3),
            "buy_ratio_h24": round(buy_ratio_h24, 3),
        },
        "liquidity_usd": liq_usd,
        "market_cap": mcap,
        "fdv": safe_float(pair.get("fdv")),
        "age_hours": round(age_hours, 1) if age_hours is not None else None,
        "flags": flags,
        "accum_score": min(score, 100),
        "created_at": created_at,
    }


def format_money(n: float) -> str:
    if n >= 1_000_000:
        return f"${n/1_000_000:.2f}M"
    if n >= 1_000:
        return f"${n/1_000:.1f}K"
    return f"${n:.0f}"


def print_analysis(a: Dict, verbose: bool = True):
    print("\n" + "=" * 70)
    print(f"  {a['base_symbol']} / {a['quote_symbol']}   |  {a['chain'].upper()}  |  {a['dex']}")
    print(f"  {a.get('base_name', '')}")
    print("=" * 70)
    print(f"  Price:          ${a['price_usd']:.8f}" if a['price_usd'] < 1 else f"  Price:          ${a['price_usd']:.4f}")
    print(f"  1h / 24h Δ:     {a['price_change_h1']:+.1f}%  /  {a['price_change_h24']:+.1f}%")
    print(f"  Market Cap:     {format_money(a['market_cap'])}   FDV: {format_money(a['fdv'])}")
    print(f"  Liquidity:      {format_money(a['liquidity_usd'])}")
    print(f"  Age:            {a['age_hours']} hours" if a['age_hours'] is not None else "  Age:            unknown")
    print()
    print("  VOLUME")
    print(f"    5m:  {format_money(a['volume']['m5'])}   1h: {format_money(a['volume']['h1'])}")
    print(f"    6h:  {format_money(a['volume']['h6'])}   24h:{format_money(a['volume']['h24'])}")
    print()
    print("  TXNS (buy pressure proxy)")
    print(f"    1h:  {a['txns']['h1_buys']:.0f} buys / {a['txns']['h1_sells']:.0f} sells  → ratio {a['txns']['buy_ratio_h1']:.1%}")
    print(f"    24h: {a['txns']['h24_buys']:.0f} buys / {a['txns']['h24_sells']:.0f} sells → ratio {a['txns']['buy_ratio_h24']:.1%}")
    print()
    print(f"  ACCUMULATION / SURGE SCORE:  {a['accum_score']}/100")
    if a["flags"]:
        print("  FLAGS:", ", ".join(a["flags"]))
    else:
        print("  FLAGS: none strong")
    print()
    print(f"  Pair:   {a['pair_address']}")
    print(f"  Token:  {a['base_address']}")
    print(f"  Chart:  {a['url']}")
    explorer = CHAIN_EXPLORERS.get(a["chain"])
    if explorer and a["base_address"]:
        print(f"  Explorer: {explorer}{a['base_address']}")
    print("=" * 70)


def recommend_next_steps(a: Dict):
    print("\n  NEXT ACTIONS (manual verification)")
    print("  1. Check labeled Smart Money / funds on Nansen or Arkham")
    print("  2. Inspect top holders + clusters on Bubblemaps / Birdeye (Sol) / Etherscan")
    print("  3. Look for exchange outflows of this token (accumulation)")
    print("  4. Verify contract, team wallets, unlock schedule, LP lock")
    print("  5. Cross-check recent large buys on Solscan / GMGN / Lookonchain")
    if a["chain"] == "solana":
        print(f"     Birdeye: https://birdeye.so/token/{a['base_address']}?chain=solana")
        print(f"     GMGN:    https://gmgn.ai/sol/token/{a['base_address']}")
    print("  6. If Binance Alpha candidate → monitor Alpha page + futures OI later")
    print()


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------
def cmd_search(args):
    q = " ".join(args.query)
    print(f"\nSearching DexScreener for: {q}")
    pairs = search_pairs(q)
    if not pairs:
        print("No pairs found.")
        return

    # Rank by a simple score (volume + buy pressure bias for small caps)
    analyzed = []
    for p in pairs[:25]:  # limit
        a = analyze_pair(p)
        if a["market_cap"] > 0 and a["market_cap"] > DEFAULT_MAX_MCAP * 3:
            continue  # skip very large
        analyzed.append(a)

    analyzed.sort(key=lambda x: (x["accum_score"], x["volume"]["h24"]), reverse=True)

    print(f"\nTop results (sorted by accum score + volume):\n")
    for i, a in enumerate(analyzed[:12], 1):
        flags_str = ",".join(a["flags"][:2]) if a["flags"] else "-"
        print(f"{i:2}. {a['base_symbol']:<10} {a['chain']:<8} "
              f"MC {format_money(a['market_cap']):>8}  "
              f"Vol24 {format_money(a['volume']['h24']):>8}  "
              f"Score {a['accum_score']:3}  {flags_str}")
        print(f"    {a['url']}")


def cmd_analyze(args):
    chain = args.chain.lower()
    addr = args.address
    print(f"\nFetching pair/token on {chain}: {addr}")

    # Try as pair first
    pair = get_pair(chain, addr)
    if not pair:
        # try as token
        pairs = get_pairs_by_token(addr)
        if not pairs:
            print("No data found. Check address / chain.")
            return
        # pick highest liquidity pair
        pairs.sort(key=lambda p: safe_float((p.get("liquidity") or {}).get("usd")), reverse=True)
        pair = pairs[0]
        print(f"Using highest-liquidity pair: {pair.get('pairAddress')}")

    a = analyze_pair(pair)
    print_analysis(a)
    recommend_next_steps(a)


def cmd_surge(args):
    """Scan search results or a seed query for volume surges + accumulation flags."""
    seed = args.query or "solana"
    print(f"\nScanning for volume surges / accumulation patterns (seed: {seed})")
    pairs = search_pairs(seed)
    if not pairs:
        # fallback seeds
        pairs = search_pairs("pump") + search_pairs("meme")
    results = []
    for p in pairs[:40]:
        a = analyze_pair(p)
        if a["accum_score"] < 25:
            continue
        if a["market_cap"] > args.max_mc:
            continue
        if a["volume"]["h24"] < args.min_vol:
            continue
        results.append(a)

    results.sort(key=lambda x: x["accum_score"], reverse=True)
    print(f"\nFound {len(results)} candidates with score ≥ 25\n")
    for a in results[:15]:
        print_analysis(a, verbose=False)
        print(f"  → {a['url']}\n")


def cmd_report(args):
    chain = args.chain.lower()
    addr = args.address
    pair = get_pair(chain, addr)
    if not pair:
        pairs = get_pairs_by_token(addr)
        if pairs:
            pairs.sort(key=lambda p: safe_float((p.get("liquidity") or {}).get("usd")), reverse=True)
            pair = pairs[0]
    if not pair:
        print("No data.")
        return

    a = analyze_pair(pair)
    print_analysis(a)
    recommend_next_steps(a)

    # JSON dump for further processing
    out = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "analysis": a,
        "raw_pair": {k: pair.get(k) for k in ["chainId", "dexId", "pairAddress", "url", "baseToken", "quoteToken"]},
    }
    fname = f"report_{a['base_symbol']}_{int(time.time())}.json"
    with open(fname, "w") as f:
        json.dump(out, f, indent=2)
    print(f"  Saved JSON report → {fname}")


def cmd_help(_args=None):
    print(__doc__)
    print("\nQuick start examples:")
    print("  python whale_accum_scanner.py search BONK")
    print("  python whale_accum_scanner.py search 0x...   # or Solana mint")
    print("  python whale_accum_scanner.py analyze solana <pair_or_mint>")
    print("  python whale_accum_scanner.py surge --min-vol 30000 --max-mc 20000000")
    print("  python whale_accum_scanner.py report ethereum 0x...")
    print("\nTips for Binance Alpha / TGE hunting:")
    print("  - Search recent Alpha tokens or new listings by name/CA")
    print("  - Look for EARLY_HIGH_ACTIVITY + STRONG_BUY_PRESSURE flags")
    print("  - Always verify on Nansen/Arkham for real smart-money labels")
    print("  - Cross-check holder concentration & funding sources")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Whale Accumulation & Volume Surge Scanner (DexScreener)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command")

    p_search = sub.add_parser("search", help="Search pairs by name / symbol / address")
    p_search.add_argument("query", nargs="+", help="Search query")

    p_analyze = sub.add_parser("analyze", help="Deep analysis of one pair or token")
    p_analyze.add_argument("chain", help="Chain id (solana, ethereum, base, bsc, ...)")
    p_analyze.add_argument("address", help="Pair address or token mint/contract")

    p_surge = sub.add_parser("surge", help="Scan for volume surges + accumulation flags")
    p_surge.add_argument("query", nargs="?", default="solana", help="Seed search query")
    p_surge.add_argument("--min-vol", type=float, default=DEFAULT_MIN_VOL_24H)
    p_surge.add_argument("--max-mc", type=float, default=DEFAULT_MAX_MCAP)

    p_report = sub.add_parser("report", help="Full report + JSON dump")
    p_report.add_argument("chain")
    p_report.add_argument("address")

    sub.add_parser("help", help="Show detailed help")

    args = parser.parse_args()
    if not args.command or args.command == "help":
        cmd_help()
        return

    if args.command == "search":
        cmd_search(args)
    elif args.command == "analyze":
        cmd_analyze(args)
    elif args.command == "surge":
        cmd_surge(args)
    elif args.command == "report":
        cmd_report(args)
    else:
        cmd_help()


if __name__ == "__main__":
    main()
