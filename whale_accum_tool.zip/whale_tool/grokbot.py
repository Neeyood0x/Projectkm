#!/usr/bin/env python3
"""
GrokBot – Whale Accumulation & Volume Surge Scanner
Telegram bot version of the on-chain research tool.

Commands:
  /start, /help
  /search <query>
  /analyze <chain> <address>
  /surge [query] [--min-vol N] [--max-mc N]
  /report <chain> <address>

Setup:
  1. Create a bot with @BotFather on Telegram → get TOKEN
  2. export TELEGRAM_BOT_TOKEN="your_token_here"
  3. pip install python-telegram-bot requests
  4. python grokbot.py

The bot reuses all logic from whale_accum_scanner.py.
"""

import asyncio
import logging
import os
import sys
from typing import Optional

# Local scanner
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from whale_accum_scanner import (
        search_pairs,
        get_pair,
        get_pairs_by_token,
        analyze_pair,
        format_money,
        safe_float,
        DEFAULT_MAX_MCAP,
        DEFAULT_MIN_VOL_24H,
        CHAIN_EXPLORERS,
    )
except ImportError as e:
    print("Could not import whale_accum_scanner.py – make sure it is in the same folder.")
    raise

# Telegram
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import (
        Application,
        CommandHandler,
        ContextTypes,
        MessageHandler,
        filters,
    )
    from telegram.constants import ParseMode
except ImportError:
    print("Install: pip install python-telegram-bot requests")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not TOKEN:
    print("Set environment variable TELEGRAM_BOT_TOKEN first.")
    print("Get one from @BotFather on Telegram.")
    sys.exit(1)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("GrokBot")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def format_analysis_telegram(a: dict) -> str:
    """Compact, readable Telegram message."""
    flags = ", ".join(a["flags"]) if a["flags"] else "none"
    price = f"${a['price_usd']:.8f}" if a["price_usd"] < 1 else f"${a['price_usd']:.4f}"

    text = (
        f"*{a['base_symbol']}* / {a['quote_symbol']}  ·  `{a['chain'].upper()}`  ·  {a['dex']}\n"
        f"{a.get('base_name', '')}\n\n"
        f"💰 Price: `{price}`\n"
        f"📈 1h / 24h: `{a['price_change_h1']:+.1f}%` / `{a['price_change_h24']:+.1f}%`\n"
        f"🏦 MC: `{format_money(a['market_cap'])}`   Liq: `{format_money(a['liquidity_usd'])}`\n"
        f"⏱ Age: `{a['age_hours']}h`\n\n"
        f"*Volume*\n"
        f"5m `{format_money(a['volume']['m5'])}` · 1h `{format_money(a['volume']['h1'])}`\n"
        f"6h `{format_money(a['volume']['h6'])}` · 24h `{format_money(a['volume']['h24'])}`\n\n"
        f"*Buy Pressure*\n"
        f"1h  {a['txns']['h1_buys']:.0f}B / {a['txns']['h1_sells']:.0f}S  → `{a['txns']['buy_ratio_h1']:.0%}`\n"
        f"24h {a['txns']['h24_buys']:.0f}B / {a['txns']['h24_sells']:.0f}S → `{a['txns']['buy_ratio_h24']:.0%}`\n\n"
        f"🎯 *Accum Score: {a['accum_score']}/100*\n"
        f"Flags: `{flags}`\n\n"
        f"Pair: `{a['pair_address']}`\n"
        f"Token: `{a['base_address']}`"
    )
    return text


def make_keyboard(a: dict) -> InlineKeyboardMarkup:
    buttons = []
    if a.get("url"):
        buttons.append([InlineKeyboardButton("📊 DexScreener Chart", url=a["url"])])
    explorer = CHAIN_EXPLORERS.get(a["chain"])
    if explorer and a.get("base_address"):
        buttons.append([InlineKeyboardButton("🔍 Explorer", url=f"{explorer}{a['base_address']}")])
    if a["chain"] == "solana" and a.get("base_address"):
        buttons.append([
            InlineKeyboardButton("Birdeye", url=f"https://birdeye.so/token/{a['base_address']}?chain=solana"),
            InlineKeyboardButton("GMGN", url=f"https://gmgn.ai/sol/token/{a['base_address']}"),
        ])
    buttons.append([
        InlineKeyboardButton("Nansen", url="https://app.nansen.ai"),
        InlineKeyboardButton("Arkham", url="https://platform.arkhamintelligence.com"),
    ])
    return InlineKeyboardMarkup(buttons)


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = (
        "🐋 *GrokBot* – Whale Accumulation Scanner\n\n"
        "I hunt volume surges and accumulation footprints on small-cap tokens "
        "(Solana, ETH, Base, BSC… ideal for Binance Alpha / TGE plays).\n\n"
        "*Commands*\n"
        "`/search <name or CA>` – find pairs & rank by score\n"
        "`/analyze <chain> <address>` – deep dive one token/pair\n"
        "`/surge [query]` – scan for current surges\n"
        "`/report <chain> <address>` – full report\n"
        "`/help` – this message\n\n"
        "Example:\n"
        "`/search AXIS`\n"
        "`/analyze solana <mint>`\n"
        "`/surge pump`\n\n"
        "_Not financial advice. Always DYOR & verify contracts._"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)


async def search_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: `/search <query>`\nExample: `/search BONK` or `/search 0x...`", parse_mode=ParseMode.MARKDOWN)
        return

    query = " ".join(context.args)
    status = await update.message.reply_text(f"🔍 Searching for *{query}* …", parse_mode=ParseMode.MARKDOWN)

    try:
        pairs = search_pairs(query)
        if not pairs:
            await status.edit_text("No pairs found.")
            return

        analyzed = []
        for p in pairs[:20]:
            a = analyze_pair(p)
            if a["market_cap"] > 0 and a["market_cap"] > DEFAULT_MAX_MCAP * 4:
                continue
            analyzed.append(a)

        analyzed.sort(key=lambda x: (x["accum_score"], x["volume"]["h24"]), reverse=True)

        lines = [f"*Search results for* `{query}`\n"]
        for i, a in enumerate(analyzed[:8], 1):
            flags = a["flags"][0] if a["flags"] else "-"
            lines.append(
                f"{i}. *{a['base_symbol']}* `{a['chain']}` "
                f"MC {format_money(a['market_cap'])} · "
                f"Vol24 {format_money(a['volume']['h24'])} · "
                f"Score *{a['accum_score']}* · `{flags}`"
            )
        lines.append("\nUse `/analyze <chain> <address>` for deep dive.")
        await status.edit_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

        # Send top result with buttons if high score
        if analyzed and analyzed[0]["accum_score"] >= 25:
            top = analyzed[0]
            await update.message.reply_text(
                format_analysis_telegram(top),
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=make_keyboard(top),
                disable_web_page_preview=True,
            )
    except Exception as e:
        logger.exception("search error")
        await status.edit_text(f"Error: {e}")


async def analyze_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text(
            "Usage: `/analyze <chain> <address>`\n"
            "Chains: solana, ethereum, base, bsc, arbitrum…\n"
            "Example: `/analyze solana So111…`",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    chain = context.args[0].lower()
    addr = context.args[1]
    status = await update.message.reply_text(f"⚡ Analyzing `{chain}` `{addr[:12]}…`", parse_mode=ParseMode.MARKDOWN)

    try:
        pair = get_pair(chain, addr)
        if not pair:
            pairs = get_pairs_by_token(addr)
            if not pairs:
                await status.edit_text("No data found. Check chain + address.")
                return
            pairs.sort(key=lambda p: safe_float((p.get("liquidity") or {}).get("usd")), reverse=True)
            pair = pairs[0]

        a = analyze_pair(pair)
        await status.edit_text(
            format_analysis_telegram(a),
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=make_keyboard(a),
            disable_web_page_preview=True,
        )
    except Exception as e:
        logger.exception("analyze error")
        await status.edit_text(f"Error: {e}")


async def surge_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = " ".join(context.args) if context.args else "solana"
    status = await update.message.reply_text(f"🚀 Scanning surges (seed: `{query}`)…", parse_mode=ParseMode.MARKDOWN)

    try:
        pairs = search_pairs(query)
        if not pairs:
            pairs = search_pairs("pump") + search_pairs("meme")

        results = []
        for p in pairs[:35]:
            a = analyze_pair(p)
            if a["accum_score"] < 25:
                continue
            if a["market_cap"] > DEFAULT_MAX_MCAP:
                continue
            if a["volume"]["h24"] < DEFAULT_MIN_VOL_24H:
                continue
            results.append(a)

        results.sort(key=lambda x: x["accum_score"], reverse=True)

        if not results:
            await status.edit_text("No strong surge / accumulation candidates right now.")
            return

        lines = [f"*Surge / Accum candidates* (seed `{query}`)\n"]
        for i, a in enumerate(results[:6], 1):
            lines.append(
                f"{i}. *{a['base_symbol']}* `{a['chain']}` "
                f"Score *{a['accum_score']}* · "
                f"MC {format_money(a['market_cap'])} · "
                f"{', '.join(a['flags'][:2])}"
            )
        await status.edit_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

        # Full card for the top one
        top = results[0]
        await update.message.reply_text(
            format_analysis_telegram(top),
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=make_keyboard(top),
            disable_web_page_preview=True,
        )
    except Exception as e:
        logger.exception("surge error")
        await status.edit_text(f"Error: {e}")


async def report_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Same as analyze for Telegram (JSON not useful in chat)
    await analyze_cmd(update, context)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error("Exception while handling update:", exc_info=context.error)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("search", search_cmd))
    app.add_handler(CommandHandler("analyze", analyze_cmd))
    app.add_handler(CommandHandler("surge", surge_cmd))
    app.add_handler(CommandHandler("report", report_cmd))
    app.add_error_handler(error_handler)

    logger.info("GrokBot starting…")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
